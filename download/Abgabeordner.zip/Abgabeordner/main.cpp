#include "spielfeld.h"

int main(int argc, char** argv) {
	
	
	//Programmargumente auswerten
    std::string file_name = "level.txt"; //level.txt muss als Standardlevel vorhanden sein!
    std::string icon_name;

    for (int i = 1; i < argc - 1; i++){
        if (argv[i][0] == '-'){
            switch (argv[i][1]) {
                case 'f':
                    file_name = (argv[i+1]);
                    break;
                case 'i':
                    icon_name = (argv[i+1]);
                    break;
                default:
                    std::cout<<"Unbekanntes Argument: "<<argv[i]<<std::endl;
                    exit(EXIT_FAILURE);
            }
        }
    }

    Spielfeld spielfeld(file_name, icon_name);

	//Spiel
    char move;
    int value;
    do {
        spielfeld.print();
        std::cout << "Naechste Bewegung: ";
        std::cin >> move;
        value = spielfeld.input(move);
        spielfeld.setNachricht(Spielfeld::interpret(value));
    }while(value > 0);

    Spielfeld::clearScreen();
    std::cout << Spielfeld::interpret(value) << std::endl;
}
