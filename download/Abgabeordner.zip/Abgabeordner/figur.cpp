#include "spielfeld.h"

/// \brief Sucht Startfeld und speichert dieses in Figur.
/// sucht das erst 'O' im Spielfeld und speichert dieses als Startkoordinate der Figur
/// \param feld Feld in dem gesucht wird
void Figur::einlesen(Feld& feld) {
    size_t zeichen_pos = std::string::npos;
    size_t i = 0;
    for(; zeichen_pos == std::string::npos && i < feld.size(); i++){
        zeichen_pos = feld.at(i).find_first_of('S');
    }
    if(zeichen_pos == std::string::npos){
        throw std::runtime_error("Kein Startfeld in Level-Datei");
    }
    zentrum = {zeichen_pos, i-1};
}

/// \brief Gibt Zentrum der Figur zurück.
/// \return Zentrum der Figur
Koordinaten Figur::getCenter() {
    return zentrum;
}

/// \brief Gibt Zeichen des Figurenicons an einem Punkt zurück.
/// \param X Position des Punktes in X-Richtung
/// \param Y Position des Punktes in Y-Richtung
/// \return Zeichen des Icons in Punkt
char Figur::getPoint(int X, int Y) {
    return bild.at(Y).at(X);
}

/// \brief Bewegt Figur in X und Y-Richtung
/// \param X Bewegung in X-Richtung
/// \param Y Bewegunf in Y-Richtung
void Figur::move(int X, int Y) {
    zentrum.second -= Y;
    zentrum.first += X;
}

/// \brief Speichert das übergebene Icon in Figur
/// \param icon icon als Icon
void Figur::setIcon(Icon& icon){
    bild = icon;
}

