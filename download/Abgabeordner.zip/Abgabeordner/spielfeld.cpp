#include "spielfeld.h"

/*
//Fix für Linux Konsolenproblem?
#if defined(__linux__)
    const std::string offset = "123456789";
#else
    const std::string offset = "";
#endif
*/

//unterschied clear linus und windows
#if defined(__linux__)
const char *const clear = "clear -x";
#else
const char *const clear = "cls";
#endif

/// \brief Liest Klartextdokumt als Feld ein.
///
/// Erstellt ein Feld der in der Datei angegebenen Größe, welches Standardmäßig mit ' ' gefüllt ist. Dieses wird dann mit der Spielfelddatei abgeändert, so das die Dimensionen bestehend bleiben. Filtert alle nichterlaubten Zeichen raus.
/// \param datei_name Pfad der Datei
/// \return eingelesene Datei in Feld
/// \pre Dateiname muss bekannt sein
Feld Spielfeld::DateiEinlesen(const std::string& datei_name){
    std::ifstream datei;
    datei.open(datei_name, std::ios::in);

    if(datei.fail()){
        throw std::runtime_error("Datei konnte nicht geladen werden!");
    }

    std::string erlaube_Zeichen = "SO-H";

    unsigned int hoehe;
    unsigned int breite;
    datei >> hoehe;
    datei >> breite;
    datei.ignore(std::string::npos, '\n');

    std::string line;
    Feld temp(hoehe, std::string(breite + 2,' '));

    for(unsigned int i = 0; i < hoehe && !datei.eof(); i++){
        std::getline(datei, line);
        for(unsigned int j = 0; j < line.size() && j < breite; j++){

            /*
                if(){		//random Steuerzeichen, iscntrl gibt 2 zurück
                    temp.at(i).at(j+1) = line.at(j);
                }
            */

            //Filtert Zeichen
            if (erlaube_Zeichen.find_first_of(line.at(j)) != std::string::npos){
                temp.at(i).at(j+1) = line.at(j);
            }
        }
    }
    return temp;
}

/// \brief Ordnet Zahlencode eine Ausgabe zu.
///
/// Gibt für jeden der Rückgabecodes der Inputfunktion eine passende Textausgabe zurück
/// Werte:
///     -2 = Ende & Verloren
///     -1 = Ende & Gewonnen
///      0 = Ende
///      1 = Nichts
///      2 = Keine Leiter
///      3 = falscher Input
///      9 = hilfe
/// \see Spielfeld::input
/// \param value Zahlendcode
/// \return Ausgabe als std::string
std::string Spielfeld::interpret(int value) {
    switch (value) {
        case 0:
            return "Programm beendet";
        case 2:
            return "Muss an einer Leiter stehen!  (? fuer Hilfe)";
        case 3:
            return "falsches Zeichen! (? fuer Hilfe)";
        case -1:
            return "Gewonnen!";
        case -2:
            return "Tod!";
        case 9:
            return "Ziel: erreiche Feld O! \n\n"
                   "Steuerung: \n"
                   "a / A: Schritt nach links \n"
                   "d / D: Schritt nach Rechts \n"
                   "s / S: Leiter herunterklettern. Muss auf Platform direkt über dieser stehen \n"
                   "w / W: Leiter hochklettern. Muss vor dieser stehen \n"
                   "?: Hilfemenu \n"
                   "q: Programm verlassen";
        default:
            return "";
    }
}

/// \brief Konstruiert ein Spielfled aus Dateipfad.
///
/// Ruft die DateiEinlesen mit Dateiname auf, und findet Start und Ziel in Spielfeld
/// \param datei_name Dateipfad
Spielfeld::Spielfeld(const std::string &datei_name, const std::string& icon_name) {


    try{
        feld = DateiEinlesen(datei_name);
        findZiel();
        figur.einlesen(feld);
    }catch(const std::runtime_error& e){
        std::cout<<"Fehler: "<<e.what()<<std::endl;
        exit(EXIT_FAILURE);
    }

    if(!icon_name.empty()){
        try{
            loadIcon(icon_name);
        }catch (std::runtime_error& e){
            nachricht = "Fehler: " + std::string(e.what());
        }
    }
}

/// \brief liest die ersten 3x3 Zeichen einer Datei als Icon für die Figur ein.
///
/// Öffnet den für das Icon übergebenen Dateipfad, und speichert die ersten 3x3 Zeichen dieser in einem gleichgroßen std::array. Übergibt dieses dann an die figur.
/// \see setIcon()
/// \param file_name Dateipfad
void Spielfeld::loadIcon(const std::string& file_name) {
    std::ifstream file;
    file.open(file_name);
    if(file.fail()){
        throw std::runtime_error("Icon konnte nicht geladen werden!");
    }
    Icon icon;

    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++) {
            file.get(icon.at(i).at(j));
        }
        file.ignore(256, '\n');
    }

    figur.setIcon(icon);
}

///\brief Sucht Zielkoordinaten in Spielfeld und speichert diese.
/// Sucht das erste 'O' im Spielfeld, und speichert die Koordinaten dieses als Ziel
void Spielfeld::findZiel() {
    size_t zeichen_pos = std::string::npos;
    size_t i = 0;
    for(; zeichen_pos == std::string::npos && i < feld.size(); i++){
        zeichen_pos = feld.at(i).find_first_of('O');
    }
    if (zeichen_pos == std::string::npos){
        throw std::runtime_error("Kein Ziel in Level-Datei");
    }
    ziel = {zeichen_pos, i-1};
}

/// \brief Überprüft ob sich Figur auf Zielfeld befindet.
/// \return 0 wenn nein, 1 wenn ja
/// \pre findZiel() muss erfolgreich ausgeführt worden sein
bool Spielfeld::checkZiel() {
    return figur.getCenter() == ziel;
}

/// \brief berechnet die Falldistanz der Figur.
/// Zählt die Felder unter der Figur bis zur nächsten Ebene, oder bis zum Spielfeldrand
/// \return Entfernung des Falls, wenn dieser kleinergleich 5, sonst -1
int Spielfeld::checkFall() {
    int dist = 0;
    for(Koordinaten pos = figur.getCenter(); dist <= 5 and pos.second + 2 < feld.size(); dist ++){
        if(feld.at(pos.second + 2).at(pos.first) ==  '-'){
            return  dist;
        }
        pos.second ++;
    }
    return -1;
}

/// \brief Gibt Spielfeld mit Figur und Nachricht aus.
/// Gibt nach 0.1s delay das Spielfeld aus, und zeichnet die Figur an ihre Position.
void Spielfeld::print() {
    clearScreen(100);
    std::cout<<nachricht<<std::endl;
    for(unsigned int i = 0; i < feld.size(); i++){
    	std::string line_out = "";
        //std::cout<<offset;	gefixt mit check für Steuerzeichen
        int relativePositionY = i + 1 - figur.getCenter().second;
        if(relativePositionY < 0 or relativePositionY > 2){
            line_out = feld.at(i);
        }
        else{
            for(unsigned int j = 0; j < feld.at(i).size(); j++){
                int relativePositionX = j + 1 - figur.getCenter().first;
                if(relativePositionX >= 0 and relativePositionX <= 2 and figur.getPoint(relativePositionX, relativePositionY) != ' ') {
                    line_out.push_back(figur.getPoint(relativePositionX, relativePositionY));
                }else {
                    line_out.push_back(feld.at(i).at(j));
                }
            }
        }
        /*
        if(line_out.find_first_of("\n") != std::string::npos){
        	std::cout<<"STEUERZEICHEN!"<<std::endl;
        }
        */
        std::cout << line_out << std::endl;
    }
}
/// \brief Cleart die Konsole
///
/// Führt den Clear Befehl der Konsole nach angebaren Delay aus ("cls" für Windows, "clear" für Linux)
/// \param delay Verzögerung in Millisekunden
void Spielfeld::clearScreen(unsigned int delay) {
    std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    std::system(clear);
    std::cout << std::flush;
}

/// \brief Speichert Nachricht in Spielfeld.
/// \param in Nachricht
void Spielfeld::setNachricht(std::string in) {
    nachricht = in;
}

/// \brief Wertet den vom Nutzer eingegebenen Zug aus.

/// bewegt die Figur und überprüft checkFall() und checkZiel();
/// \see figur::move
/// \pre Nutzereingabe muss vorhanden sein und
/// \param dir Zug
/// \return Zahlencode über Zustand des Zuges
int Spielfeld::input(char dir) {
    switch (dir) {
        case 'a': case 'A':{
            figur.move(-1, 0);
            break;
        }
        case 'd': case 'D':{
            figur.move(1, 0);
            break;
        }
        case 's': case 'S':{
            unsigned x = figur.getCenter().first;
            unsigned y = figur.getCenter().second;

            if (feld.at(y + 3).at(x) == 'H') {
                figur.move(0, -1);
                y += 1;
                while (feld.at(y + 2).at(x) == 'H') {
                    figur.move(0, -1);
                    y += 1;
                }
            } else {
                return 2;
            }
            break;
        }
        case 'w': case 'W':{
            unsigned x = figur.getCenter().first;
            unsigned y = figur.getCenter().second;

            if (feld.at(y + 1).at(x) == 'H') {
                figur.move(0, 1);
                y -= 1;
                while (feld.at(y + 2).at(x) == 'H') {
                    figur.move(0, 1);
                    y -= 1;
                }
            } else {
                return 2;
            }
            break;
        }
        case '?':
            return 9;
        case 'q':
            std::system(clear);
            return 0;
        default:
            return 3;
    }

    if(int fall = checkFall()){
        if(fall == -1){
            return -2;
        }else{
            figur.move(0,-fall);
        }
    }

    if (checkZiel()){
        return -1;
    }

    return 1;
}