#pragma once

#include <vector>
#include <string>
#include <utility>
#include <array>
#include <fstream>
#include <iostream>
#include <cctype>
#include <chrono>
#include <thread>

#include"figur.h"

using Feld = std::vector<std::string>;
using Koordinaten = std::pair<unsigned int, unsigned int>;
using Icon = std::array<std::array<char,3>,3>;


/// \brief Stellt gesamtes Spiel da.
///
/// Liest Spielfeld-Datei aus, Speichert diese und sucht informationen über Start- und Endpunkt heraus. Nimmt eingaben Entgegen und wertet diese aus. Zeichnet Spielfeld.
/// \see Figur

class Spielfeld{
private:
    std::string nachricht;
    Feld feld;
    Figur figur;
    Koordinaten ziel;
public:
    static Feld DateiEinlesen(const std::string&);

    Spielfeld(const std::string&, const std::string&);

    void loadIcon(const std::string&);
    void findZiel();
    bool checkZiel();
    int checkFall();
    void print();
    static void clearScreen(unsigned int delay = 0);

    void setNachricht(std::string);

    int input(char);
    static std::string interpret(int);
};