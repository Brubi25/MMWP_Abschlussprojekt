using Feld = std::vector<std::string>;
using Koordinaten = std::pair<unsigned int, unsigned int>;
using Icon = std::array<std::array<char,3>,3>;


/// \brief Klasse für die Spielerfigur
///
/// Speichert Position und Aussehen der Figur, liest Startposition der Figur aus. Bewegt Figur.
class Figur{
private:
    Icon bild{std::array<char, 3>{' ', 'o', ' '},{'/', 'I', '\\'},{'/', ' ', '\\'} };

    Koordinaten zentrum;
public:

    void einlesen(Feld&);
    char getPoint(int, int);
    void move(int, int);
    void setIcon(Icon&);

    Koordinaten getCenter();
};